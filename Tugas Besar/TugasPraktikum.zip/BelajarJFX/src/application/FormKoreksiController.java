package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


/**
 * Home Controller.
 */
public class FormKoreksiController extends AnchorPane  implements Initializable {
	private Stage parentStage;
	   
    @FXML Button btnKeluar;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    	btnKeluar.setOnAction((ActionEvent event) -> {
    		parentStage.close();
    	});
    }

	public void setStage(Stage temp){
        parentStage = temp;
    }
}
