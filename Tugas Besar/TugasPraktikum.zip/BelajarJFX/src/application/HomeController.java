/*
 * Copyright (c) 2008, 2012 Oracle and/or its affiliates.
 * All rights reserved. Use is subject to license terms.
 *
 * This file is available and licensed under the following license:
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the distribution.
 *  - Neither the name of Oracle Corporation nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package application;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;

import application.Database.Database;
import application.Model.GetDailyBarang;
import application.Model.Supplier;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.event.ActionEvent;

import org.controlsfx.control.action.Action;
import org.controlsfx.dialog.Dialogs;
import org.controlsfx.dialog.Dialog;

/**
 * Home Controller.
 */
public class HomeController extends AnchorPane  implements Initializable {
	@FXML
	Button btnLogout;
	@FXML
	TabPane tabpane;
	@FXML
	Button btnDataBarang;
	@FXML
	Button btnDataSupplier;
	@FXML
	Button btnInputBarang;
	@FXML
	Button btnKoreksi;
	@FXML
	Button btnInputSupplier;
	
	Label formfilter;
	public TextField txtfilter;
	
	Database db = new Database();
	Connection conn = db.getConnection();
	
	private Stage primaryStage, secondaryStage;
	
	private Main application;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		btnDataBarang.setOnAction((ActionEvent e) -> {
			showTableBarang();
        });
		
		btnDataSupplier.setOnAction((ActionEvent e) -> {
			showTableSupplier();
		});
		
		btnInputBarang.setOnAction(e -> handleControl("Tambah"));
		
		btnKoreksi.setOnAction(e -> handleControl("Koreksi"));
		
		btnInputSupplier.setOnAction(e -> handleControl("Supplier"));
		
		btnLogout.setOnAction((ActionEvent e) -> {
			if (application == null){
	            // We are running in isolated FXML, possibly in Scene Builder.
	            // NO-OP.
				System.out.println("Gak Keluar");
	            return;
	        }
			System.out.println("Keluar");
	        application.userLogout();
		});
	}
	
	private Object handleControl(String e) {
		if("Tambah".equals(e)) {
			try {
    			FXMLLoader fl = new FXMLLoader();
    	        fl.setLocation(getClass().getResource("FormBarang.fxml"));
    	        fl.load();
    	        Parent root = fl.getRoot();
    	       
    	        secondaryStage = new Stage(StageStyle.DECORATED);
    	        secondaryStage.initModality(Modality.APPLICATION_MODAL);
    	        secondaryStage.initStyle(StageStyle.TRANSPARENT);
    	        secondaryStage.initOwner(primaryStage);
    	        Scene scene = new Scene(root);
    	        scene.getStylesheets().add(getClass().getResource("validation.css").toExternalForm());
    	        
    	        FormBarangController t1 = (FormBarangController)fl.getController();
    	        t1.setStage(secondaryStage);
    	        secondaryStage.setScene(scene);
    	        secondaryStage.show();
    		} catch (Exception ex) {
    			ex.printStackTrace();
    		}
		}
		
		else if("Koreksi".equals(e)) {
			try {
    			FXMLLoader fl = new FXMLLoader();
    	        fl.setLocation(getClass().getResource("FormKoreksi.fxml"));
    	        fl.load();
    	        Parent root = fl.getRoot();
    	       
    	        secondaryStage = new Stage(StageStyle.DECORATED);
    	        secondaryStage.initModality(Modality.APPLICATION_MODAL);
    	        secondaryStage.initStyle(StageStyle.TRANSPARENT);
    	        secondaryStage.initOwner(primaryStage);
    	        Scene scene = new Scene(root);
    	       
    	        FormKoreksiController t1 = (FormKoreksiController)fl.getController();
    	        t1.setStage(secondaryStage);
    	        secondaryStage.setScene(scene);
    	        secondaryStage.show();
    		} catch (Exception ex) {
    			ex.printStackTrace();
    		}
		}
		
		else if("Supplier".equals(e)) {
			try {
    			FXMLLoader fl = new FXMLLoader();
    	        fl.setLocation(getClass().getResource("FormSupplier.fxml"));
    	        fl.load();
    	        Parent root = fl.getRoot();
    	       
    	        secondaryStage = new Stage(StageStyle.DECORATED);
    	        secondaryStage.initModality(Modality.APPLICATION_MODAL);
    	        secondaryStage.initStyle(StageStyle.TRANSPARENT);
    	        secondaryStage.initOwner(primaryStage);
    	        Scene scene = new Scene(root);
    	       
    	        FormSupplierController t1 = (FormSupplierController)fl.getController();
    	        t1.setStage(secondaryStage);
    	        secondaryStage.setScene(scene);
    	        secondaryStage.show();
    		} catch (Exception ex) {
    			ex.printStackTrace();
    		}
		}
		return null;
	}
	
	public void setStage(Stage temp){
        primaryStage = temp;
    }
	
	public void showTableBarang() {
		Tab tab1 = new Tab("Data Barang");
		
        CreateTable table = new CreateTable();
        
        formfilter = new Label();
        formfilter.setText("Filter : ");
        txtfilter = new TextField();
        txtfilter.setMinWidth(30);
        
        Image imageOk = new Image(getClass().getResourceAsStream("pics/Add.png"));
        Button button1 = new Button("Add");
        button1.setGraphic(new ImageView(imageOk));
        button1.setMaxWidth(90);
        button1.setOnAction(e -> handleControl("Tambah"));
        
        Image imageDel = new Image(getClass().getResourceAsStream("pics/Delete.png"));
        Button button2 = new Button("Del");
        button2.setGraphic(new ImageView(imageDel));
        button2.setMaxWidth(90);
        button2.setOnAction((ActionEvent t) -> {
        	Action response = Dialogs.create()
        	        //.owner()
        	        .title("Confirm Dialog")
        	        .masthead(null)
        	        .message("Do you want to continue?")
        	        .showConfirm();

        	if (response == Dialog.Actions.YES) {
        			table.barang.remove(table.table.getSelectionModel().getSelectedItem());
	        		String id = table.getText_TextArea();
	        		table.barang.remove(id);
	        		String sql = "DELETE FROM `tblbarang` WHERE KodeBarang='"+id+"'";
	            	try {
	    				PreparedStatement ps = conn.prepareStatement(sql);
	    				ps.executeUpdate();
	    				
	    			} catch (Exception e1) {
	    				// TODO Auto-generated catch block
	    				e1.printStackTrace();
	    			}
	            	System.out.println();
        	} else {
        		Dialogs.create()
	                //.owner()
	                .title("Information Dialog")
	                .masthead(null)
	                .message("Dibatalkan!")
	                .showInformation();
        	}
        });
        
        Image imageEdit = new Image(getClass().getResourceAsStream("pics/Pen.png"));
        Button button3 = new Button("Edit");
        button3.setGraphic(new ImageView(imageEdit));
        button3.setMaxWidth(90);
        
        Image imageRefresh = new Image(getClass().getResourceAsStream("pics/refresh.png"));
        Button button4 = new Button("Refresh");
        button4.setGraphic(new ImageView(imageRefresh));
        button4.setMaxWidth(90);
        button4.setOnAction((ActionEvent t) -> {
        	table.service1.restart();
        });
        
        VBox vbox = new VBox(5);
        HBox hbox1 = new HBox(5);
        HBox hbox = new HBox(5);
        vbox.setPadding(new Insets(30, 160, 0, 160));
        hbox1.getChildren().addAll(formfilter, txtfilter);
        hbox1.setAlignment(Pos.CENTER_RIGHT);
        hbox.getChildren().addAll(button1, button2, button3, button4);
        hbox.setAlignment(Pos.CENTER_RIGHT);
        vbox.getChildren().addAll(hbox1, table.getTableBarang(), hbox);
		
        tab1.setContent(vbox);
		
		tabpane.getTabs().add(tab1);
        tabpane.getSelectionModel().select(tab1);
	}

	public void showTableSupplier() {
		Tab tab2 = new Tab("Data Supplier");
		
        CreateTable table = new CreateTable();
        
        Image imageOk = new Image(getClass().getResourceAsStream("pics/Add.png"));
        Button button1 = new Button("Add");
        button1.setGraphic(new ImageView(imageOk));
        button1.setMaxWidth(90);
        
        Image imageDel = new Image(getClass().getResourceAsStream("pics/Delete.png"));
        Button button2 = new Button("Del");
        button2.setGraphic(new ImageView(imageDel));
        button2.setMaxWidth(90);
        
        Image imageEdit = new Image(getClass().getResourceAsStream("pics/Pen.png"));
        Button button3 = new Button("Edit");
        button3.setGraphic(new ImageView(imageEdit));
        button3.setMaxWidth(90);
        
        Image imageRefresh = new Image(getClass().getResourceAsStream("pics/refresh.png"));
        Button button4 = new Button("Refresh");
        button4.setGraphic(new ImageView(imageRefresh));
        button4.setMaxWidth(90);
        button4.setOnAction((ActionEvent t) -> {
        	table.service2.restart();
        });
        
        
        VBox vbox = new VBox(5);
        HBox hbox = new HBox(5);
        vbox.setPadding(new Insets(30, 160, 0, 160));
        hbox.getChildren().addAll(button1, button2, button3, button4);
        hbox.setAlignment(Pos.CENTER_RIGHT);
        vbox.getChildren().addAll(table.getTableSupplier(), hbox);
		
        tab2.setContent(vbox);
		
		tabpane.getTabs().add(tab2);
        tabpane.getSelectionModel().select(tab2);
	}

	public void setApp(Main application) {
		this.application = application;
	}
}
