package application.Model;

import javafx.collections.ObservableList;
import javafx.concurrent.Service;
import javafx.concurrent.Task;

public class GetDailySupplierService extends Service<ObservableList<Supplier>> {

    @Override
    protected Task<ObservableList<Supplier>> createTask() {
        return new GetDailySupplier();
    }
}