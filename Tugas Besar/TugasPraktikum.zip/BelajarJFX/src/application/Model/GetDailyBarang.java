package application.Model;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import application.HomeController;
import application.Database.Database;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.concurrent.Task;
import javafx.fxml.Initializable;


 

public class GetDailyBarang extends Task<ObservableList<Barang>> {
	
    @Override
    protected ObservableList<Barang> call() throws Exception {
    	for (int i = 0; i < 200; i++) {
            updateProgress(i, 200);
            Thread.sleep(5);
        }
		return null;
    }
}