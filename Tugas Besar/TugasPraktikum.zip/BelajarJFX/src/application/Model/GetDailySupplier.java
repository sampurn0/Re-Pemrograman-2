package application.Model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import application.HomeController;
import application.Database.Database;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.concurrent.Task;


 

public class GetDailySupplier extends Task<ObservableList<Supplier>> {
	private IntegerProperty index = new SimpleIntegerProperty();
	HomeController hc;
	
    @Override
    protected ObservableList<Supplier> call() throws Exception {
    	for (int i = 0; i < 200; i++) {
            updateProgress(i, 200);
            Thread.sleep(5);
        }
    	Database db = new Database(); 
		Connection conn = db.getConnection();
        
        ObservableList<Supplier> supplier = FXCollections.observableArrayList();
        String SQL = "SELECT * FROM tblsupplier";
        ResultSet rs;
		try {
			rs = conn.createStatement().executeQuery(SQL);			
			while(rs.next()){
				Supplier row = new Supplier();
				row.KodeSupplier.set(rs.getString("KodeSupplier"));
				row.NamaSupplier.set(rs.getString("NamaSupplier")); 
				row.Alamat.set(rs.getString("Alamat")); 
				row.Telepon.set(rs.getString("telepon")); 
				row.KontakPerson.set(rs.getString("KontakPerson")); 
				supplier.add(row);
	        }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		
        return supplier;
    }
}