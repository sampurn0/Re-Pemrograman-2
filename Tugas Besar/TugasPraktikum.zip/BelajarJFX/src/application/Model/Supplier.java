package application.Model;

import javafx.beans.property.SimpleStringProperty;

public class Supplier {
	public SimpleStringProperty  KodeSupplier = new SimpleStringProperty();
	public SimpleStringProperty  NamaSupplier = new SimpleStringProperty ();
	public SimpleStringProperty  Alamat = new SimpleStringProperty ();
	public SimpleStringProperty Telepon = new SimpleStringProperty();
	public SimpleStringProperty KontakPerson = new SimpleStringProperty();
	public String kodeSupplier;
	
	public Supplier() {
	}
	
	public void setkodeSupplier(String x) {
		this.kodeSupplier = x;
	}
	
	public String getkodeSupplier() {
	    return this.kodeSupplier;
	}
	
	public String getKodeSupplier() {
	    return KodeSupplier.get();
	}
	
	public String getNamaSupplier() {
		return NamaSupplier.get();
	}
	
	public String getAlamat() {
		return Alamat.get();
	}
	
	public String getTelepon() {
		return Telepon.get();
	}
	
	public String getKontakPerson() {
		return KontakPerson.get();
	}
}