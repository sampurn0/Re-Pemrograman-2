package application.Model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Barang {
	public SimpleStringProperty  KodeBarang = new SimpleStringProperty();
	public SimpleStringProperty  NamaBarang = new SimpleStringProperty ();
	public SimpleStringProperty  Satuan = new SimpleStringProperty ();
	public SimpleStringProperty HargaPokok = new SimpleStringProperty();
	public SimpleStringProperty Stok = new SimpleStringProperty();
	public SimpleStringProperty  Kategori = new SimpleStringProperty ();
	public SimpleStringProperty  Supplier = new SimpleStringProperty ();
	public SimpleStringProperty  Merk = new SimpleStringProperty ();
	public SimpleStringProperty  Seri = new SimpleStringProperty ();
	public SimpleStringProperty StokBS = new SimpleStringProperty();
	
	public String getKodeBarang() {
	    return KodeBarang.get();
	}
	
	public StringProperty kodebarangProperty() {
		return KodeBarang;
	}
	
	public String getNamaBarang() {
		return NamaBarang.get();
	}
	
	public String getSatuan() {
		return Satuan.get();
	}
	
	public String getHargaPokok() {
		return HargaPokok.get();
	}
	
	public String getStok() {
		return Stok.get();
	}
	
	public String getKategori() {
		return Kategori.get();
	}
	
	public String getSupplier() {
		return Supplier.get();
	}
	
	public String getMerk() {
		return Merk.get();
	}
	
	public String getSeri() {
		return Seri.get();
	}
	
	public String getStokBS() {
		return StokBS.get();
	} 
}