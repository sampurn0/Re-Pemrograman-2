package application.Model;

import javafx.collections.ObservableList;
import javafx.concurrent.Service;
import javafx.concurrent.Task;

public class GetDailyBarangService extends Service<ObservableList<Barang>> {

    @Override
    protected Task<ObservableList<Barang>> createTask() {
        return new GetDailyBarang();
    }
}