package application;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import application.FormBarangController;
import application.Database.Database;
import application.Model.Supplier;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.SelectionModel;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TableView.TableViewSelectionModel;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Callback;


/**
 * Home Controller.
 */
public class FormCariSupplierController extends AnchorPane  implements Initializable {
	private Stage thirdStage;
	Database db = new Database();
	Connection conn = db.getConnection();
	String val1, val2;
	private Supplier sup;
	
	FormBarangController parent;
	ObservableList<Supplier> supplier = FXCollections.observableArrayList();
	
	@FXML
	private TableView<Supplier> tblViewer;
	@FXML
	private TableColumn colKodeSupplier;
	@FXML
	private TableColumn colNamaSupplier;
	
	@FXML Button btnKeluar;
	@FXML Button pilih;
    
	
	
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    	sup = new Supplier();
    	
    	btnKeluar.setOnAction((ActionEvent event) -> {
    		thirdStage.close();
    	});
    	
    	pilih.setOnAction((ActionEvent event) -> {
    		try {
    			parent.BKodeSupplier.setText(val1);
    			parent.BNamaSupplier.setText(val2);
    			thirdStage.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	});
    	
    	Callback<TableColumn, TableCell> integerCellFactory =
                new Callback<TableColumn, TableCell>() {
            @Override
            public TableCell call(TableColumn p) {
                MyIntegerTableCell cell = new MyIntegerTableCell();
                cell.addEventFilter(MouseEvent.MOUSE_CLICKED, new MyEventHandler());
                return cell;
            }
        };
 
        Callback<TableColumn, TableCell> stringCellFactory =
                new Callback<TableColumn, TableCell>() {
            @Override
            public TableCell call(TableColumn p) {
                MyStringTableCell cell = new MyStringTableCell();
                cell.addEventFilter(MouseEvent.MOUSE_CLICKED, new MyEventHandler());
                return cell;
            }
        };
    	
    	colKodeSupplier.setCellValueFactory(new PropertyValueFactory<Supplier, String>("KodeSupplier"));
    	colKodeSupplier.setCellFactory(stringCellFactory);
    	
    	colNamaSupplier.setCellValueFactory(new PropertyValueFactory<Supplier, String>("NamaSupplier"));
    	colNamaSupplier.setCellFactory(stringCellFactory);
    	
        String SQL = "SELECT * FROM tblsupplier";
        ResultSet rs;
		try {
			rs = conn.createStatement().executeQuery(SQL);			
			while(rs.next()){
				Supplier row = new Supplier();
				row.KodeSupplier.set(rs.getString("KodeSupplier"));
				row.NamaSupplier.set(rs.getString("NamaSupplier")); 

				supplier.add(row);
	        }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		tblViewer.getItems().setAll(supplier);
    }
    
    public class MyIntegerTableCell extends TableCell<Supplier, Integer> {
    	 
        @Override
        public void updateItem(Integer item, boolean empty) {
            super.updateItem(item, empty);
            setText(empty ? null : getString());
            setGraphic(null);
        }
 
        private String getString() {
            return getItem() == null ? "" : getItem().toString();
        }
    }
 
    public class MyStringTableCell extends TableCell<Supplier, String> {
 
        @Override
        public void updateItem(String item, boolean empty) {
            super.updateItem(item, empty);
            setText(empty ? null : getString());
            setGraphic(null);
        }
 
        private String getString() {
            return getItem() == null ? "" : getItem().toString();
        }
    }
    
    public class MyEventHandler implements EventHandler<MouseEvent> {
    	 
        @Override
        public void handle(MouseEvent t) {
            TableCell c = (TableCell) t.getSource();
            int index = c.getIndex();
            //System.out.println("kode = " + supplier.get(index).getKodeSupplier());
            //System.out.println("name = " + supplier.get(index).getNamaSupplier());
            val1 = supplier.get(index).getKodeSupplier();
            val2 = supplier.get(index).getNamaSupplier();
            System.out.println(val1 + " " + val2);
        }
    }
    
    public Supplier getKode(){
        return sup;
    }

    public void setStage(Stage temp){
		thirdStage = temp;
    }
    
    public void setParent(FormBarangController par){
		parent = par;
    }
}
