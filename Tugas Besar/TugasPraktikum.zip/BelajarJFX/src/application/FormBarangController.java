package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.controlsfx.dialog.Dialogs;
import org.controlsfx.validation.ValidationSupport;
import org.controlsfx.validation.Validator;
import org.controlsfx.validation.decoration.CompoundValidationDecoration;
import org.controlsfx.validation.decoration.GraphicValidationDecoration;
import org.controlsfx.validation.decoration.StyleClassValidationDecoration;
import org.controlsfx.validation.decoration.ValidationDecoration;

import application.Database.Database;
import application.Model.GetDailyBarangService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;



/**
 * Home Controller.
 */
public class FormBarangController extends AnchorPane  implements Initializable {
	protected Stage secondaryStage, thirdStage;
	Database db = new Database();
	Connection conn = db.getConnection();   
	
	final GetDailyBarangService service = new GetDailyBarangService();  
	
	@FXML Button btnKeluar;
	@FXML Button btnKeluar2;
    @FXML Button btnSimpan;
    @FXML Button inputSupplier;
    @FXML Button cariSupplier;    
    
    @FXML TextField BKodeBarang;
    @FXML TextField BNamaBarang;
    @FXML TextField BKodeSupplier = new TextField();
    @FXML TextField BNamaSupplier;
    @FXML ComboBox<String>  BKategori;
    @FXML ComboBox<String>  BSatuan;
    @FXML TextField BHargaPokok;
    @FXML TextField BHargaLama;
    @FXML TextField BStok;
    @FXML TextField BMerk;
    @FXML TextField BSeri;
    
    String KodeSupplier;
    final FormBarangController FBC = this;
    
    ValidationSupport validationSupport = new ValidationSupport();
    ValidationDecoration iconDecorator = new GraphicValidationDecoration();
    ValidationDecoration cssDecorator = new StyleClassValidationDecoration();
    ValidationDecoration compoundDecorator = new CompoundValidationDecoration(cssDecorator, iconDecorator);
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    	validationSupport.setValidationDecorator(compoundDecorator);
    	String SQL = "SELECT * FROM tblkategori";
    	try {
			ResultSet rs = conn.createStatement().executeQuery(SQL);
			while(rs.next()){
				BKategori.getItems().add(rs.getString("Kategori"));
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}	
    	
    	String SQL1 = "SELECT * FROM tblitemsatuan";
    	try {
			ResultSet rs = conn.createStatement().executeQuery(SQL1);
			while(rs.next()){
				BSatuan.getItems().add(rs.getString("NamaSatuan"));
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
    	
    	inputSupplier.setOnAction(e -> handleControl("Input Supplier"));
    	
    	cariSupplier.setOnAction(e -> handleControl("Cari Supplier"));
		
    	btnKeluar.setOnAction((ActionEvent event) -> {
    		secondaryStage.close();
    	});
    	
    	btnSimpan.setOnAction((ActionEvent event) -> {
    		String  kdbarang   	= BKodeBarang.getText();
    		String  nmbarang   	= BNamaBarang.getText();
    		String  kdsupplier 	= BKodeSupplier.getText();
    		String  nmsupplier 	= BNamaSupplier.getText();
    		String  kategori   	= BKategori.getValue();
    		String  satuan	  	= BSatuan.getValue();
    		String  hargapokok 	= BHargaPokok.getText();
    		String  hargalama  	= BHargaLama.getText();
    		String  stok		= BStok.getText();
    		String  merk		= BMerk.getText();
    		String  seri		= BSeri.getText();
    		
    		if (kdbarang.equals("") || nmbarang.equals("") || kdsupplier.equals("") || nmsupplier.equals("") || kategori.equals("") || satuan .equals("") || hargapokok.equals("") || hargalama.equals("") || stok.equals("") || merk.equals("") || seri.equals("")) {
    			System.out.println("Kode Barang		-> " + kdbarang);
    			System.out.println("Nama Barang 	-> " + nmbarang);
    			System.out.println("Kode Supplier 	-> " + kdsupplier);
    			System.out.println("Nama Supplier 	-> " + nmsupplier);
    			System.out.println("Kategori 		-> " + kategori);
    			System.out.println("Satuan 			-> " + satuan);
    			System.out.println("Harga Pokok 	-> " + hargapokok);
    			System.out.println("Harga Lama 		-> " + hargalama);
    			System.out.println("Stok 			-> " + stok);
    			System.out.println("Merk 			-> " + merk);
    			System.out.println("Seri 			-> " + seri);
    			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
    			
    			Dialogs.create()
	    	        .owner(secondaryStage)
	    	        .title("Error Dialog")
	    	        .masthead(null)
	    	        .message("Ooops, there was an error!")
	    	        .showError();
    			
    			validationSupport.registerValidator(BKodeBarang, Validator.createEmptyValidator(""));
    			validationSupport.registerValidator(BNamaBarang, Validator.createEmptyValidator(""));
    			validationSupport.registerValidator(BKodeSupplier, Validator.createEmptyValidator(""));
    			validationSupport.registerValidator(BNamaSupplier, Validator.createEmptyValidator(""));
    			validationSupport.registerValidator(BKategori, Validator.createEmptyValidator(""));
    			validationSupport.registerValidator(BSatuan, Validator.createEmptyValidator(""));
    			validationSupport.registerValidator(BHargaPokok, Validator.createEmptyValidator(""));
    			validationSupport.registerValidator(BHargaLama, Validator.createEmptyValidator(""));
    			validationSupport.registerValidator(BStok, Validator.createEmptyValidator(""));
    			validationSupport.registerValidator(BMerk, Validator.createEmptyValidator(""));
    			validationSupport.registerValidator(BSeri, Validator.createEmptyValidator(""));
        	} else {
        		insert(kdbarang, nmbarang, kdsupplier, nmsupplier, kategori, satuan, hargapokok, hargalama, stok, merk, seri);
        	}
    	});
    }
    
    private Object handleControl(String e) {
    	if("Input Supplier".equals(e)) {
			try {
    			FXMLLoader fl = new FXMLLoader();
    	        fl.setLocation(getClass().getResource("FormSupplier.fxml"));
    	        fl.load();
    	        Parent root = fl.getRoot();
    	       
    	        thirdStage = new Stage(StageStyle.DECORATED);
    	        thirdStage.initModality(Modality.APPLICATION_MODAL);
    	        thirdStage.initStyle(StageStyle.TRANSPARENT);
    	        thirdStage.initOwner(secondaryStage);
    	        Scene scene = new Scene(root);
    	        scene.getStylesheets().add(getClass().getResource("validation.css").toExternalForm());
    	        
    	        FormSupplierController t1 = (FormSupplierController)fl.getController();
    	        t1.setStage(thirdStage);
    	        thirdStage.setScene(scene);
    	        thirdStage.show();
    		} catch (Exception ex) {
    			ex.printStackTrace();
    		}
		}
    	
    	else if("Cari Supplier".equals(e)) {
			try {
				FXMLLoader fl = new FXMLLoader();
		        fl.setLocation(getClass().getResource("FormPencarianSupplier.fxml"));
				fl.load();
		        Parent root = fl.getRoot();
		        
		        thirdStage = new Stage(StageStyle.DECORATED);
		        thirdStage.initModality(Modality.APPLICATION_MODAL);
		        thirdStage.initStyle(StageStyle.TRANSPARENT);
		        thirdStage.initOwner(secondaryStage);
		        Scene scene = new Scene(root);
		        scene.getStylesheets().add(getClass().getResource("validation.css").toExternalForm());
		        
		        FormCariSupplierController t1 = (FormCariSupplierController)fl.getController();
		        t1.setStage(thirdStage);
		        t1.setParent(FBC);
		        thirdStage.setScene(scene);
		        thirdStage.show();
    		} catch (Exception ex) {
    			ex.printStackTrace();
    		}
		}
		return null;
	}

	public void setStage(Stage temp){
		secondaryStage = temp;
    }
    

	public void reload() throws IOException { 
		//secondaryStage.close();
		System.out.println("reload");
		FXMLLoader fl = new FXMLLoader();
        fl.setLocation(getClass().getResource("FormBarang.fxml"));
        fl.load();
        Parent root = fl.getRoot();
       
        thirdStage = new Stage(StageStyle.DECORATED);
        thirdStage.initModality(Modality.APPLICATION_MODAL);
        thirdStage.initStyle(StageStyle.TRANSPARENT);
        thirdStage.initOwner(secondaryStage);
        Scene scene = new Scene(root);
        scene.getStylesheets().add(getClass().getResource("validation.css").toExternalForm());
        
        thirdStage.setScene(scene);
        thirdStage.show();
	}
	
    private void insert(String kdbarang, String nmbarang, String kdsupplier, String nmsupplier, String kategori, String satuan, String hargapokok, String hargalama,String stok, String merk, String seri){
    	
    	String sql = "insert into tblbarang (KodeBarang,NamaBarang,KodeSupplier,NamaSupplier,Kategori,Satuan,HargaBeli,HargaModal,Stok,StokLama,Merk,seri)";
		sql += "values (?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1,kdbarang);
			ps.setString(2,nmbarang);
			ps.setString(3,kdsupplier);
			ps.setString(4,nmsupplier);
			ps.setString(5,kategori);
			ps.setString(6,satuan);
			ps.setString(7,hargapokok);
			ps.setString(8,hargapokok);
			ps.setString(9,stok);
			ps.setString(10,stok);
			ps.setString(11,merk);
			ps.setString(12,seri);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	
    	Dialogs.create()
	        .owner(secondaryStage)
	        .title("Information Dialog")
	        .masthead(null)
	        .message("I have a great message for you!")
	        .showInformation();
    	secondaryStage.close();
    	service.restart();
    }
    
    public void setText_TextArea(String s){
    	BKodeSupplier.setText(s);
    }
}
