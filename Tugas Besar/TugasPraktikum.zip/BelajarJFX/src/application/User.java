package application;

import java.util.HashMap;
import java.util.Map;

public class User {
	private static final Map<String, User> USERS = new HashMap<String, User>();
	String pass;
	
    public static User of(String pass) {
        User user = USERS.get(pass);
        if (user == null) {
            user = new User(pass);
            USERS.put(pass, user);
        }
        return user;
    }

    private User(String pass) {
        this.pass = pass;
    }

    public String getPass() {
        return pass;
    }
}