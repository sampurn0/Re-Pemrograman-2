package application;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import application.Database.Database;
import application.Model.Barang;
import application.Model.GetDailyBarangService;
import application.Model.GetDailySupplierService;
import application.Model.Supplier;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.util.Callback;



public class CreateTable {
	public final GetDailyBarangService service1 = new GetDailyBarangService();  
	public final GetDailySupplierService service2 = new GetDailySupplierService();  
	ObservableList<Barang> barang;
	TableView table;
	ObservableList<Supplier> supplier;
	String val1, val2;
    
	public Parent getTableBarang() {
		String[] namaKolom = new String[]{"Kode Barang", "Nama Barang", "Satuan", "Harga Pokok", "Stok", "Kategori", "Supplier", "Merk", "Seri", "Stol BS"};
		String[] factory = new String[]{"KodeBarang", "NamaBarang", "Satuan", "HargaPokok", "Stok", "Kategori", "Supplier", "Merk", "Seri", "StokBS"};
		barang = FXCollections.observableArrayList();
		Database db = new Database(); 
		Connection conn = db.getConnection();
		
		table = new TableView();
		Region veil = new Region();
		veil.setStyle("-fx-background-color: rgba(0, 0, 0, 0.4)");
		ProgressIndicator p = new ProgressIndicator();
        p.setMaxSize(150, 150);
		
        Callback<TableColumn, TableCell> stringCellFactory =
                new Callback<TableColumn, TableCell>() {
            @Override
            public TableCell call(TableColumn p) {
                MyStringTableCell cell = new MyStringTableCell();
                cell.addEventFilter(MouseEvent.MOUSE_CLICKED, new MyEventHandler());
                return cell;
            }
        };
        
        TableColumn col1 = new TableColumn();
        col1.setText("Kode Barang");
        col1.setCellValueFactory(new PropertyValueFactory<Barang, String>("KodeBarang"));
        col1.setCellFactory(stringCellFactory);
        
        TableColumn col2 = new TableColumn();
        col2.setText("Nama Barang");
        col2.setCellValueFactory(new PropertyValueFactory<Barang, String>("NamaBarang"));
        col2.setCellFactory(stringCellFactory);
        
        TableColumn col3 = new TableColumn();
        col3.setText("Satuan");
        col3.setCellValueFactory(new PropertyValueFactory<Barang, String>("Satuan"));
        col3.setCellFactory(stringCellFactory);
        
        TableColumn col4 = new TableColumn();
        col4.setText("Harga Pokok");
        col4.setCellValueFactory(new PropertyValueFactory<Barang, String>("HargaPokok"));
        col4.setCellFactory(stringCellFactory);
        
        TableColumn col5 = new TableColumn();
        col5.setText("Stok");
        col5.setCellValueFactory(new PropertyValueFactory<Barang, String>("Stok"));
        col5.setCellFactory(stringCellFactory);
        
        TableColumn col6 = new TableColumn();
        col6.setText("Kategori");
        col6.setCellValueFactory(new PropertyValueFactory<Barang, String>("Kategori"));
        col6.setCellFactory(stringCellFactory);

        TableColumn col7 = new TableColumn();
        col7.setText("Supplier");
        col7.setCellValueFactory(new PropertyValueFactory<Barang, String>("Supplier"));
        col7.setCellFactory(stringCellFactory);
        
        TableColumn col8 = new TableColumn();
        col8.setText("Merk");
        col8.setCellValueFactory(new PropertyValueFactory<Barang, String>("Merk"));
        col8.setCellFactory(stringCellFactory);
        
        TableColumn col9 = new TableColumn();
        col9.setText("Seri");
        col9.setCellValueFactory(new PropertyValueFactory<Barang, String>("Seri"));
        col9.setCellFactory(stringCellFactory);
        
        TableColumn col10 = new TableColumn();
        col10.setText("StokBS");
        col10.setCellValueFactory(new PropertyValueFactory<Barang, String>("StokBS"));
        col10.setCellFactory(stringCellFactory);

        table.getColumns().addAll(col1,col2,col3,col4,col5,col6,col7,col8,col9,col10);
        
        barang = FXCollections.observableArrayList();
        String SQL = "SELECT * FROM tblbarang LEFT JOIN tblsupplier ON tblbarang.KodeSupplier=tblsupplier.KodeSupplier";
        ResultSet rs;
		try {
			rs = conn.createStatement().executeQuery(SQL);			
			while(rs.next()){
				Barang row = new Barang();
				row.KodeBarang.set(rs.getString("KodeBarang"));
				row.NamaBarang.set(rs.getString("NamaBarang")); 
				row.Satuan.set(rs.getString("Satuan")); 
				row.HargaPokok.set(rs.getString("HargaBeli")); 
				row.Stok.set(rs.getString("Stok")); 
				row.Kategori.set(rs.getString("Kategori")); 
				row.Supplier.set(rs.getString("NamaSupplier"));
				row.Merk.set(rs.getString("Merk"));  
				row.Seri.set(rs.getString("Seri")); 
				row.StokBS.set(rs.getString("StokBS"));
				barang.add(row);
	        }
			table.setItems(barang);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println(getText_TextArea());
        StackPane stack = new StackPane();
        stack.getChildren().addAll(table, veil, p);
        
        p.progressProperty().bind(service1.progressProperty());
        veil.visibleProperty().bind(service1.runningProperty());
        p.visibleProperty().bind(service1.runningProperty());
        table.getItems().add(barang);
        
        service1.start();
		return stack;
	}
	
	public Parent getTableSupplier() {
		String[] namaKolom = new String[]{"Kode Supplier", "Nama Supplier", "Alamat", "Telepon", "Kontak Person"};
		String[] factory = new String[]{"KodeSupplier", "NamaSupplier", "Alamat", "Telepon", "KontakPerson"};
		supplier = FXCollections.observableArrayList();
		
		TableView<Supplier> table = new TableView<>();
		Region veil = new Region();
		veil.setStyle("-fx-background-color: rgba(0, 0, 0, 0.4)");
		ProgressIndicator p = new ProgressIndicator();
        p.setMaxSize(150, 150);
		
        for (int i = 0; i < namaKolom.length; i++) {
            TableColumn tc = new TableColumn(namaKolom[i]);
            System.out.println(namaKolom.length);
            final int colNo = i;
            tc.setCellValueFactory(new PropertyValueFactory<Supplier, String[]>(factory[i]));
            tc.prefWidthProperty().bind(table.widthProperty().divide(namaKolom.length));
            table.getColumns().add(tc);
        }
        
        StackPane stack = new StackPane();
        stack.getChildren().addAll(table, veil, p);
        
        p.progressProperty().bind(service2.progressProperty());
        veil.visibleProperty().bind(service2.runningProperty());
        p.visibleProperty().bind(service2.runningProperty());
        table.itemsProperty().bind(service2.valueProperty());
        
        service2.start();
		return stack;
	}
	
	public class MyStringTableCell extends TableCell<Barang, String> {
		 
        @Override
        public void updateItem(String item, boolean empty) {
            super.updateItem(item, empty);
            setText(empty ? null : getString());
            setGraphic(null);
        }
 
        private String getString() {
            return getItem() == null ? "" : getItem().toString();
        }
    }
	
	public class MyEventHandler implements EventHandler<MouseEvent> {
   	 
        @Override
        public void handle(MouseEvent t) {
            TableCell c = (TableCell) t.getSource();
            int index = c.getIndex();
            //System.out.println("kode = " + supplier.get(index).getKodeSupplier());
            //System.out.println("name = " + supplier.get(index).getNamaSupplier());
            val1 = barang.get(index).getHargaPokok();
            val2 = barang.get(index).getKodeBarang();
            setText_TextArea(val2);
            //System.out.println(val1 + " " + val2);
        }
    }
	
	String a;
	public void setText_TextArea(String s){
    	this.a = s;
    }
	
	public String getText_TextArea() {
    	return a;
    }
}