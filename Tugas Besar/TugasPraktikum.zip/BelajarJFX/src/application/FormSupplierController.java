package application;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.controlsfx.dialog.Dialogs;
import org.controlsfx.validation.ValidationSupport;
import org.controlsfx.validation.Validator;
import org.controlsfx.validation.decoration.CompoundValidationDecoration;
import org.controlsfx.validation.decoration.GraphicValidationDecoration;
import org.controlsfx.validation.decoration.StyleClassValidationDecoration;
import org.controlsfx.validation.decoration.ValidationDecoration;

import application.Database.Database;
import application.Model.GetDailySupplierService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


/**
 * Home Controller.
 */
public class FormSupplierController extends AnchorPane  implements Initializable {
	private Stage parentStage;
	Database db = new Database();
	Connection conn = db.getConnection();      
	
    @FXML Button btnKeluar;
    @FXML Button btnSimpan;
    @FXML TextField SKodeSupplier;
    @FXML TextField SNamaSupplier;
    @FXML TextField SAlamat;
    @FXML TextField STelepon;
    @FXML TextField SKontakPerson;
    
    final GetDailySupplierService service = new GetDailySupplierService();  
    
    ValidationSupport validationSupport = new ValidationSupport();
    ValidationDecoration iconDecorator = new GraphicValidationDecoration();
    ValidationDecoration cssDecorator = new StyleClassValidationDecoration();
    ValidationDecoration compoundDecorator = new CompoundValidationDecoration(cssDecorator, iconDecorator);
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    	validationSupport.setValidationDecorator(compoundDecorator);
    	btnKeluar.setOnAction((ActionEvent event) -> {
    		parentStage.close();
    	});
    	
    	btnSimpan.setOnAction((ActionEvent event) -> {
    		String kodesupplier = SKodeSupplier.getText();
    		String namasupplier = SNamaSupplier.getText();
    		String alamat		= SAlamat.getText();
    		String telepon		= STelepon.getText();
    		String kontakperson	= SKontakPerson.getText();
    		
    		if (kodesupplier.equals("") || namasupplier.equals("") || alamat.equals("") || telepon.equals("") || kontakperson.equals("")) { 
    			Dialogs.create()
	    	        .owner(parentStage)
	    	        .title("Error Dialog")
	    	        .masthead(null)
	    	        .message("Ooops, there was an error!")
	    	        .showError();
    			
    			validationSupport.registerValidator(SKodeSupplier, Validator.createEmptyValidator(""));
    			validationSupport.registerValidator(SNamaSupplier, Validator.createEmptyValidator(""));
    			validationSupport.registerValidator(SAlamat, Validator.createEmptyValidator(""));
    			validationSupport.registerValidator(STelepon, Validator.createEmptyValidator(""));
    			validationSupport.registerValidator(SKontakPerson, Validator.createEmptyValidator(""));
    		} else {
    			insert(kodesupplier, namasupplier, alamat, telepon, kontakperson);
    		}
    	});
    }

    private void insert(String kodesupplier, String namasupplier, String alamat, String telepon, String kontakperson) {
    	
    	String sql = "insert into tblsupplier (KodeSupplier,NamaSupplier,Alamat,telepon,KontakPerson)";
		sql += "values (?,?,?,?,?)";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1,kodesupplier);
			ps.setString(2,namasupplier);
			ps.setString(3,alamat);
			ps.setString(4,telepon);
			ps.setString(5,kontakperson);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	
    	Dialogs.create()
	        .owner(parentStage)
	        .title("Information Dialog")
	        .masthead(null)
	        .message("I have a great message for you!")
	        .showInformation();
    	parentStage.close();
    	
    	CreateTable ct = new CreateTable();
    	ct.service2.restart();
    }
    
	public void setStage(Stage temp){
        parentStage = temp;
    }
}
